import numpy as np
from trash_target_tracker import TrashTargetTracker

class StaticTrashTracker(TrashTargetTracker):
 """Freeze goal after three-frame confirmation; later vision is verification only."""
 def __init__(self,label='trash'):
  super().__init__(label);self.frozen=False;self.verify_stamps=[]
 def ingest(self,result,robot_xy,now):
  if not self.frozen:
   super().ingest(result,robot_xy,now)
   if self.confirmed:
    self.frozen=True;self.events.append(dict(event='world_goal_frozen',time_s=now,goal=self.goal.tolist(),surface=self.anchor.tolist()))
   return
  if result['frame_id']<=self.last_frame:return
  self.last_frame=result['frame_id'];stamp=result['simulation_time_s']
  if now-stamp>self.max_result_age:return
  valid=[d for d in result['detections'] if d['class'] in ['milk jug','plastic water bottle','crumpled tissue paper'] and d.get('valid_depth_pixels',0)>=9 and 'surface_median_world_xyz' in d and np.linalg.norm(np.array(d['surface_median_world_xyz'])[:2]-self.anchor)<.12]
  if valid:
   d=min(valid,key=lambda d:np.linalg.norm(np.array(d['surface_median_world_xyz'])[:2]-self.anchor))
   self.last_seen=stamp;self.verify_stamps.append(stamp);self.accepted.append(dict(frame_id=result['frame_id'],time_s=now,world_xyz=d['surface_median_world_xyz'],original_class=d['class']))
 def allowed(self,now):
  if not self.frozen:return super().allowed(now)
  state='navigating_fixed_goal' if now-self.last_seen<=.8 else 'navigating_from_memory'
  if state!=self.state:self.events.append(dict(event=state,time_s=now))
  self.state=state;return True
