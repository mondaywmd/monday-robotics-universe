from static_trash_tracker import StaticTrashTracker
class RotationStaticTracker(StaticTrashTracker):
 def __init__(self,label='trash'):
  super().__init__(label)
  # Static target, pose at capture already supplied; 3 CPU passes take ~0.7 sim s.
  # This does not change LiDAR/depth freshness or motion safety checks.
  self.max_result_age=1.2
