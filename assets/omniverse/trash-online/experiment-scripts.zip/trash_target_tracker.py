import numpy as np
from live_target_tracker import TargetTracker

class TrashTargetTracker(TargetTracker):
 """One spatially locked trash target. No access to scene identity/coordinates."""
 def __init__(self,label='trash'):
  super().__init__('trash');self.lock_origin=None;self.accepted=[]
 def ingest(self,result,robot_xy,now):
  if result['frame_id']<=self.last_frame:return
  if now-result['simulation_time_s']>self.max_result_age:
   super().ingest(result,robot_xy,now);return
  candidates=[d for d in result['detections'] if d['class'] in ['milk jug','plastic water bottle','crumpled tissue paper'] and d.get('valid_depth_pixels',0)>=9 and 'surface_median_world_xyz' in d]
  anchor=self.anchor if self.anchor is not None else self.lock_origin
  if anchor is not None:
   candidates=[d for d in candidates if np.linalg.norm(np.array(d['surface_median_world_xyz'])[:2]-anchor)<.12 and np.linalg.norm(np.array(d['surface_median_world_xyz'])[:2]-self.lock_origin)<.18]
  # Initially prefer nearby detected trash; subsequent frames match by position,
  # not by fluctuating subtype/confidence. Lost target does not switch automatically.
  reference=np.array(robot_xy) if anchor is None else anchor
  selected=min(candidates,key=lambda d:np.linalg.norm(np.array(d['surface_median_world_xyz'])[:2]-reference)) if candidates else None
  if selected is not None:
   point=np.array(selected['surface_median_world_xyz'])[:2]
   if self.lock_origin is None:
    self.lock_origin=point.copy();self.events.append(dict(event='spatial_target_lock',time_s=now,surface=point.tolist(),original_class=selected['class']))
   self.accepted.append(dict(frame_id=result['frame_id'],time_s=now,world_xyz=selected['surface_median_world_xyz'],original_class=selected['class']))
  super().ingest({**result,'detections':[{**selected,'class':'trash'}] if selected else []},robot_xy,now)
