from pathlib import Path
import os,json,time,torch,cv2,html
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from ultralytics import YOLOE
from rotation_trash_detector import detect_rotations,PROMPTS,LABELS
root=Path(__file__).resolve().parents[1];out=sorted((root/'outputs/trash-online').glob('prompt-validation-*/manifest.json'))[-1].parent;data=json.loads((out/'manifest.json').read_text());os.chdir(root/'work/perception-models');torch.set_num_threads(6);model=YOLOE('yoloe-11s-seg.pt');model.set_classes(PROMPTS,model.get_text_pe(PROMPTS));extra=PROMPTS+['plastic bottle lying on its side']; embeddings={False:model.get_text_pe(PROMPTS),True:model.get_text_pe(extra)}; rows=[];font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',16)
for e in data['records']:
 im=cv2.imread(str(out/(e['stem']+'.png')));depth=np.load(out/(e['stem']+'.npy'));row={k:v for k,v in e.items() if k not in ['bounds','camera_to_world']};panels=[]
 for mode,rotations,extended in [('baseline',(0,),False),('side_prompt',(0,),True),('rotation',(0,-1,1),False),('side_rotation',(0,-1,1),True)]:
  prompts=extra if extended else PROMPTS; labels=LABELS+['plastic water bottle'] if extended else LABELS;model.set_classes(prompts,embeddings[extended])
  begin=time.perf_counter();detections=detect_rotations(model,im,rotations,prompts,labels);duration=time.perf_counter()-begin;items=[];pic=Image.fromarray(im[:,:,::-1]);draw=ImageDraw.Draw(pic)
  for d in detections:
   mask=cv2.erode(d.pop('mask').astype(np.uint8),np.ones((3,3),np.uint8)).astype(bool);yy,xx=np.where(mask&np.isfinite(depth)&(depth>.04)&(depth<4));identity='unmatched'
   if len(xx)>=9:
    z=depth[yy,xx];pts=np.stack([(xx+.5-320)*z/e['fx'],-(yy+.5-240)*z/e['fy'],-z,np.ones(len(z))],axis=1)@np.array(e['camera_to_world']);point=np.median(pts[:,:3],axis=0);scores=sorted((sum(max(lo-v,0,v-hi)**2 for v,lo,hi in zip(point,b['min'],b['max']))**.5,n) for n,b in e['bounds'].items());identity=scores[0][1] if scores and scores[0][0]<=.06 else 'unmatched'
   d['associated_object']=identity;items.append(d);draw.rectangle(d['box_xyxy'],outline='#00eeaa',width=2);draw.text((d['box_xyxy'][0],max(35,d['box_xyxy'][1]-20)),f"trash {d['confidence']:.2f}",font=font,fill='#00ffbb',stroke_width=1,stroke_fill='black')
  detected=any(d['associated_object']=='water_bottle_01' for d in items);row[mode]=dict(water_detected=detected,detections=items,inference_s=duration);draw.rectangle((0,0,640,30),fill='black');draw.text((6,5),f'{mode} | water: {detected} | negative: {e["negative"]}',font=font,fill='white');panels.append(pic)
 joined=Image.new('RGB',(1280,960));
 for j,panel in enumerate(panels):joined.paste(panel,((j%2)*640,(j//2)*480))
 joined.save(out/(e['stem']+'-comparison.jpg'));rows.append(row)
positive=[r for r in rows if not r['negative']];negative=[r for r in rows if r['negative']];summary={mode:dict(positive_water_detections=sum(r[mode]['water_detected'] for r in positive),positive_total=len(positive),negative_frames_with_detection=sum(bool(r[mode]['detections']) for r in negative),negative_total=len(negative),median_inference_s=float(np.median([r[mode]['inference_s'] for r in rows]))) for mode in ['baseline','side_prompt','rotation','side_rotation']}
(out/'results.json').write_text(json.dumps(dict(summary=summary,records=rows),indent=2))
intro='<h1>YOLOE Zero-Shot Baseline: prompt and rotation comparison</h1><p>Fresh 20 positive views and 6 all-trash-hidden book/shoe negatives. Same asset and room. Top: baseline / added lying-bottle prompt. Bottom: rotations / added prompt plus rotations. All classes count as trash; no fine-tuning. Boxes use actual model outputs. Object bounds are used only for offline association, which can be affected by depth error.</p><pre>'+html.escape(json.dumps(summary,indent=2))+'</pre>'
for r in rows:intro+=f'<h2>{r["stem"]} · yaw {r["angle"]} · {r["distance_m"]} m · negative {r["negative"]}</h2><img src="{r["stem"]}-comparison.jpg">'
(out/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>YOLOE prompt comparison</title><style>body{font:17px/1.6 system-ui;max-width:1280px;margin:25px auto;padding:20px;background:#f5f4ed}img{max-width:100%}pre{white-space:pre-wrap}</style>'+intro,encoding='utf-8');print(out);print(json.dumps(summary,indent=2))
