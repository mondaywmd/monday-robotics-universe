"""Fixed original + +/-90 degree inference; restore masks before depth use."""
import cv2,numpy as np
PROMPTS=['milk bottle with handle','plastic water bottle','crumpled tissue paper']
LABELS=['milk jug','plastic water bottle','crumpled tissue paper']
def detect_rotations(model,bgr,rotations=(0,-1,1),prompts=None,labels=None):
 prompts=PROMPTS if prompts is None else prompts;labels=LABELS if labels is None else labels
 h,w=bgr.shape[:2];detections=[]
 for k in rotations:
  view=np.ascontiguousarray(np.rot90(bgr,k));r=model.predict(view,conf=.4,imgsz=960,device='cpu',verbose=False)[0]
  if r.masks is None:continue
  for i,b in enumerate(r.boxes):
   mask=cv2.resize(r.masks.data[i].cpu().numpy(),(view.shape[1],view.shape[0]),interpolation=cv2.INTER_NEAREST);mask=np.ascontiguousarray(np.rot90(mask,-k)>.5)
   yy,xx=np.where(mask)
   if len(xx)<9:continue
   detections.append(dict(**{'class':labels[int(b.cls.item())]},prompt=prompts[int(b.cls.item())],confidence=float(b.conf.item()),box_xyxy=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)],mask=mask,rotation_quarters=k))
 # Class-agnostic overlap suppression: all three categories are trash.
 keep=[]
 for d in sorted(detections,key=lambda d:d['confidence'],reverse=True):
  if any(np.count_nonzero(d['mask']&p['mask'])/max(1,min(np.count_nonzero(d['mask']),np.count_nonzero(p['mask'])))>.6 for p in keep):continue
  keep.append(d)
 return keep
