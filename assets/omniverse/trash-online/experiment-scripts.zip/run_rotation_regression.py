import asyncio,builtins,json,math,random,heapq,sys,hashlib,torch,time
from scipy.ndimage import distance_transform_edt
from pathlib import Path
import numpy as np
import omni.usd,omni.timeline,omni.kit.app
from pxr import Usd,UsdGeom,UsdPhysics,PhysxSchema,Gf

CASES={}
sys.path.insert(0,'C:/Users/User/Documents/ChatGPT/RL Navigation/work')
import importlib;importlib.invalidate_caches()
import static_trash_tracker,trash_target_tracker,live_target_tracker
importlib.reload(live_target_tracker);importlib.reload(trash_target_tracker);importlib.reload(static_trash_tracker)
from rotation_static_tracker import RotationStaticTracker as TargetTracker
from reachable_parking import choose_parking
ONLINE_ROOT=Path('C:/Users/User/Documents/ChatGPT/RL Navigation/outputs/trash-online')
RUN_ID=time.strftime('%Y%m%d-%H%M%S')+'-rotationregression'
LABELS={'paper_wad_01':'crumpled tissue paper','milk_bottle_01':'milk jug','water_bottle_01':'plastic water bottle'}
BENCHMARK=json.loads((ONLINE_ROOT/'layout-benchmark-manifest.json').read_text())
policy_dir=Path(r'C:/Users/User/Documents/navbot/_isaacsim/isaacsim/policies/clean_start_temporal_lidar_v1')
sys.path.insert(0,str(policy_dir))
from clean_actor import CleanMirrorActor
from observation78 import build_observation
from temporal_lidar import sector_minima,signed_range_rate
weights=policy_dir/'actor_latest.pth'
digest=hashlib.sha256(weights.read_bytes()).hexdigest()
actor=CleanMirrorActor().cpu()
actor.load_state_dict(torch.load(str(weights),map_location='cpu',weights_only=True),strict=True)
actor.eval()


async def run_case(layout,name='paper_wad_01',seed=71,blocked_case=False,record=True):
 ctx=omni.usd.get_context();t=omni.timeline.get_timeline_interface();app=omni.kit.app.get_app()
 root=Path('C:/Users/User/Documents/navbot/_isaacsim')
 folder=ONLINE_ROOT/(RUN_ID+'-'+layout['id']+'-'+name);folder.mkdir(parents=True,exist_ok=True)
 (folder/'maps').mkdir();map_log=[];arrival_time=None;arrival_confirmed=False;parking_goal=None;parking_events=[];scan_events=[];scan_index=0;scan_hold=None
 (folder/'requests').mkdir();(folder/'results').mkdir();tracker=TargetTracker('trash');perception_log=[];control_events=[];pending=None;frame_id=0;next_vision=0.;last_result_wall=time.monotonic()
 async def frames(n):
  for _ in range(n):await app.next_update_async()
 t.stop();t.commit();await frames(15)
 if hasattr(builtins,'navbot_lidar_sensor'):
  builtins.navbot_lidar_sensor._invalidate_sensor();del builtins.navbot_lidar_sensor
 await ctx.open_stage_async('C:/Users/User/Documents/ChatGPT/RL Navigation/outputs/trash-individual/'+name+'/scene.usda');await frames(60)
 s=ctx.get_stage();assert UsdGeom.GetStageMetersPerUnit(s)==1
 targets=['/World/Trash'];CASES[name]=[]
 assert any('approved_appearance.usda' in p for p in s.GetRootLayer().subLayerPaths)
 # All ground-truth geometry below is exclusively scene setup / offline scoring.
 def place(path,xy,rot):
  prim=s.GetPrimAtPath(path);prim.SetActive(True);x=UsdGeom.Xformable(prim);x.ClearXformOpOrder()
  shift=x.AddTranslateOp();shift.Set(Gf.Vec3d(0,0,0));x.AddRotateXYZOp().Set(Gf.Vec3f(*rot))
  cache=UsdGeom.BBoxCache(Usd.TimeCode.Default(),['default','render','proxy']);b=cache.ComputeWorldBound(prim).ComputeAlignedRange()
  assert not b.IsEmpty(),path
  low=b.GetMin();high=b.GetMax();shift.Set(Gf.Vec3d(xy[0]-(low[0]+high[0])/2,xy[1]-(low[1]+high[1])/2,.005-low[2]))
 for asset,pose in layout['objects'].items():place('/World/Trash/'+asset,pose['xy'],pose['rotation'])
 for kind in layout['distractors']:
  path='/World/Trash/distractor_'+kind;prim=UsdGeom.Xform.Define(s,path).GetPrim();prim.GetReferences().AddReference('C:/Users/User/Documents/simforge_assets/'+kind+'_01/usd/'+kind+'_01.usda')
  place(path,[-.05,-2.20] if kind=='book' else [-.60,-2.45],[0,0,0])
 await frames(20)
 cache=UsdGeom.BBoxCache(Usd.TimeCode.Default(),['default','render','proxy']);truth={}
 for prim in s.GetPrimAtPath('/World/Trash').GetChildren():
  if prim.IsActive():
   b=cache.ComputeWorldBound(prim).ComputeAlignedRange();truth[prim.GetName()]={'min':list(b.GetMin()),'max':list(b.GetMax())}
 (folder/'layout.json').write_text(json.dumps(dict(layout=layout,bounds=truth),indent=2))
 s.GetRootLayer().Export(str(folder/'scene.usda'))
 s=ctx.get_stage();em=app.get_extension_manager()
 for ext in ['isaacsim.sensors.experimental.rtx','isaacsim.sensors.rtx.nodes']:em.set_extension_enabled_immediate(ext,True)
 cp='/World/NavBot/Geometry/base_footprint/base_link/TrashRGBCamera';dc=UsdGeom.Camera.Define(s,cp);dc.CreateFocalLengthAttr(12);dc.CreateHorizontalApertureAttr(20.14);dc.CreateVerticalApertureAttr(15.105);dc.CreateClippingRangeAttr(Gf.Vec2f(.04,4));dx=UsdGeom.Xformable(dc);dx.ClearXformOpOrder();dx.AddTransformOp().Set(Gf.Matrix4d().SetLookAt(Gf.Vec3d(.085,0,.18),Gf.Vec3d(1,0,-.08),Gf.Vec3d(0,0,1)).GetInverse())
 import omni.replicator.core as rep
 rp=rep.create.render_product(cp,(640,480));da=rep.AnnotatorRegistry.get_annotator('distance_to_image_plane');da.attach([rp]);ra=rep.AnnotatorRegistry.get_annotator('rgb');ra.attach([rp]);memory=[];rng=np.random.default_rng(71);depth_counts=[];occupied=set();resolution=.025;origin=np.array([-2.,-5.]);shape=(160,320);depth_fresh=0
 from isaacsim.sensors.experimental.rtx import Lidar,LidarSensor,parse_generic_model_output_data
 from omni.physics.tensors import create_simulation_view
 from omni.kit.viewport.utility import get_active_viewport,capture_viewport_to_file
 sensor=LidarSensor(Lidar('/World/NavBot/Geometry/base_footprint/base_link/base_scan/Lidar',aux_output_level='FULL',reset_xform_op_properties=False),annotators=['generic-model-output'])
 builtins.navbot_lidar_sensor=sensor
 bodies=[str(p.GetPath()) for p in s.Traverse() if str(p.GetPath()).startswith('/World/NavBot/') and p.HasAPI(UsdPhysics.RigidBodyAPI)]
 for path in bodies:PhysxSchema.PhysxContactReportAPI.Apply(s.GetPrimAtPath(path)).CreateThresholdAttr(0)
 filters=[str(p.GetPath()) for p in s.Traverse() if str(p.GetPath()).startswith(tuple(targets)) and p.HasAPI(UsdPhysics.CollisionAPI)]+[str(p.GetPath()) for p in s.Traverse() if str(p.GetPath()).startswith('/World/Corridor/Collision/') and p.HasAPI(UsdPhysics.CollisionAPI) and p.GetName()!='Floor']
 assert len(filters)>0
 drives=[UsdPhysics.DriveAPI.Get(s.GetPrimAtPath('/World/NavBot/Physics/'+n),'angular') for n in ['wheel_left_joint','wheel_right_joint']]
 def command(v,w):
  for d,side in zip(drives,[-1,1]):d.GetTargetVelocityAttr().Set(math.degrees((v+side*w*.16/2)/.033))
 from omni import physx
 sim_clock=[0.]
 physics_subscription=physx.get_physx_interface().subscribe_physics_step_events(lambda dt:sim_clock.__setitem__(0,sim_clock[0]+float(dt)))
 command(0,0);t.play();t.commit();await frames(90)
 sim=create_simulation_view('numpy',stage_id=ctx.get_stage_id())
 body=sim.create_rigid_body_view('/World/NavBot/Geometry/base_footprint/base_link')
 contact=sim.create_rigid_contact_view(bodies,[filters for _ in bodies])
 assert contact.sensor_count==len(bodies) and contact.filter_count==len(filters)
 goal=np.array([0.,0.]);begin=sim_clock[0];last=None;fresh=begin;previous=0.;history=[];max_force=0.;reason='timeout'
 best=float('inf');progress_time=begin;captures=[];next_capture=begin;previous_sector=None;previous_action=np.zeros(2,np.float32);previous_scan_time=begin;policy_decisions=0;route_fallbacks=0;terminal_decisions=0
 vp=get_active_viewport();cfg=json.loads((root/'tests/navigation/scanned_chair/observation_camera.json').read_text(encoding='utf-8'));cam=UsdGeom.Camera.Define(s,'/World/NavTestCamera');cam.CreateFocalLengthAttr(cfg['focal_length']);cam.CreateClippingRangeAttr(Gf.Vec2f(.01,100));cx=UsdGeom.Xformable(cam);cx.AddTransformOp().Set(Gf.Matrix4d(*[v for row in cfg['world_transform'] for v in row]));cx.GetOrderedXformOps()[0].Set(Gf.Matrix4d().SetLookAt(Gf.Vec3d(.05,-5.116,1.25),Gf.Vec3d(-.30,-1.0,.05),Gf.Vec3d(0,0,1)).GetInverse());vp.set_active_camera(cp);await frames(15)
 if record:(folder/'frames').mkdir(exist_ok=True)
 import omni.ui as ui
 live_window=ui.Window('Live YOLOE - online target tracking',width=670,height=570)
 with live_window.frame:
  with ui.VStack():
   live_status=ui.Label('Waiting for visual confirmation',height=30)
   live_image=ui.Image(width=640,height=480)
 builtins.live_perception_window=live_window

 try:
  while sim_clock[0]-begin<35:
   await frames(1);now=sim_clock[0]
   elapsed=now-begin
   if elapsed>=25 and arrival_time is None:reason="navigation_timeout";break
   tr0=body.get_transforms().copy()[0];pos0=tr0[:2].astype(float)
   if pending is not None and pending.exists():
    try:result=json.loads(pending.read_text())
    except (OSError,json.JSONDecodeError):
     command(0,0);await frames(1);continue
    last_result_wall=time.monotonic()
    tracker.ingest(result,pos0,elapsed);perception_log.append({'frame_id':result['frame_id'],'captured_s':result['simulation_time_s'],'consumed_s':elapsed,'age_s':elapsed-result['simulation_time_s'],'detections':result['detections'],'inference_wall_s':result['inference_wall_s'],'robot_xyz':tr0[:3].tolist(),'tracker_state':tracker.state,'last_seen_s':tracker.last_seen,'anchor':tracker.anchor.tolist() if tracker.anchor is not None else None})
    live_image.source_url=result['annotated_image'];pending=None
   allowed=tracker.allowed(elapsed)
   if tracker.goal is not None:goal=parking_goal.copy() if parking_goal is not None else tracker.goal.copy()
   live_status.text=f'{name} | {tracker.state} | confirmed={allowed} | goal updates={tracker.updates}'
   if not allowed:
    command(0,0);previous_action=np.array([2*.1/.35-1,0.],dtype=np.float32);control_events.append({'time_s':elapsed,'selection':'visual_hold','state':tracker.state,'v_mps':0.,'w_radps':0.})
   if pending is not None and time.monotonic()-last_result_wall>20:
    reason='detector_wall_timeout';break
   if pending is None and elapsed>=next_vision:
    # Freeze physics only while sampling RGB, depth and transform, preventing pose skew.
    t.pause();t.commit();await frames(3)
    rgb=np.array(ra.get_data());dep=np.array(da.get_data()).squeeze()
    if rgb.shape[:2]==(480,640) and dep.shape==(480,640):
     from PIL import Image
     prefix=folder/'requests'/f'{frame_id:05d}';Image.fromarray(rgb).save(str(prefix)+'.png');np.save(str(prefix)+'.npy',dep)
     matrix=np.array(dc.ComputeLocalToWorldTransform(0)).tolist()
     meta={'frame_id':frame_id,'simulation_time_s':sim_clock[0]-begin,'fx':640*12/20.14,'fy':480*12/15.105,'camera_to_world':matrix,'target_label':'trash','tracker_state':tracker.state,'sampling':'physics paused for aligned RGB/depth/pose snapshot'}
     temp=prefix.with_suffix('.tmp');temp.write_text(json.dumps(meta));temp.replace(prefix.with_suffix('.json'));pending=folder/'results'/f'{frame_id:05d}.json';frame_id+=1
    t.play();t.commit();next_vision=elapsed+.2;last_result_wall=time.monotonic()
   forces=contact.get_contact_force_matrix(1/60);max_force=max(max_force,float(np.abs(forces).max()))
   if max_force>.1:reason='contact';break
   data,_=sensor.get_data('generic-model-output');g=parse_generic_model_output_data(data)
   if g.numElements and g.scanComplete and g.frameId!=last:
    last=g.frameId;fresh=now;tr=body.get_transforms().copy()[0];pos=tr[:2].astype(float);qx,qy,qz,qw=tr[3:7]
    yaw=math.atan2(2*(qw*qz+qx*qy),1-2*(qy*qy+qz*qz));dist=float(np.linalg.norm(goal-pos))
    if not allowed:continue
    if parking_goal is not None and dist<.04 and arrival_time is None:
     command(0,0);arrival_time=elapsed;tracker.events.append(dict(event='arrived_at_selected_parking',time_s=elapsed))
    if dist<best-.025:best=dist;progress_time=now
    if arrival_time is None and now-progress_time>18:reason='blocked_no_progress';break
    a=np.deg2rad(np.array(g.x,copy=True));r=np.array(g.z,copy=True);valid=np.isfinite(r)&(r>=.12)&(r<=3.5)
    rays=np.full(360,3.5,dtype=np.float32)
    ray_idx=(np.rint(np.array(g.x,copy=True)[valid]).astype(int)+180)%360
    np.minimum.at(rays,ray_idx,r[valid].astype(np.float32))
    sectors=sector_minima(rays,.12,3.5)
    scan_dt=max(.001,now-previous_scan_time)
    rates=np.zeros(36,np.float32) if previous_sector is None else signed_range_rate(previous_sector,sectors,scan_dt)
    goal_heading=(math.atan2(goal[1]-pos[1],goal[0]-pos[0])-yaw+math.pi)%(2*math.pi)-math.pi
    observation=build_observation(sectors,rates,previous_action,dist,goal_heading)
    with torch.no_grad():raw=actor(observation).cpu().numpy()[0]
    requested_v=-.10+(float(raw[0])+1)*.35/2
    requested_w=.8*float(raw[1])
    previous_sector=sectors.copy();previous_scan_time=now
    points=np.column_stack((r[valid]*np.cos(a[valid])-.032,r[valid]*np.sin(a[valid])))
    d=np.array(da.get_data()).squeeze()
    if d.shape==(480,640):
     yy,xx=np.indices(d.shape);pc=np.stack([(xx-319.5)*d/(640*12/20.14),-(yy-239.5)*d/(480*12/15.105),-d,np.ones_like(d)],axis=-1).reshape(-1,4);valid=np.isfinite(pc).all(1)&(d.ravel()>.04)&(d.ravel()<2.0);world=(pc[valid]@np.array(dc.ComputeLocalToWorldTransform(0)))[:,:3]
     sample=world[rng.choice(len(world),min(2500,len(world)),replace=False)];plane_best=None
     for _ in range(70):
      q=sample[rng.choice(len(sample),3,replace=False)];n=np.cross(q[1]-q[0],q[2]-q[0]);norm=np.linalg.norm(n)
      if norm<1e-8:continue
      n/=norm
      if n[2]<0:n=-n
      if n[2]<.97:continue
      off=-n@q[0];count=int((np.abs(sample@n+off)<.005).sum())
      if plane_best is None or count>plane_best[0]:plane_best=(count,n,off)
     if plane_best is not None:
      _,n,off=plane_best;depth_fresh=now;heights=world@n+off;obstacles=world[(heights>.012)&(heights<.25)];grid=np.unique(np.round(obstacles[:,:2]/.02).astype(int),axis=0)*.02;memory.append((now,grid));depth_counts.append(len(grid))
    memory=[(tm,ps) for tm,ps in memory if now-tm<3.0]
    if memory:
     extra=np.vstack([ps for _,ps in memory]);delta=extra-pos;rot=np.array([[math.cos(yaw),math.sin(yaw)],[-math.sin(yaw),math.cos(yaw)]]);extra=delta@rot.T;extra=extra[np.linalg.norm(extra,axis=1)>.13];points=np.vstack([points,extra])
    if now-depth_fresh>.6:reason='stale_depth';break
    c,ss=math.cos(yaw),math.sin(yaw);rotation=np.array([[c,-ss],[ss,c]])
    wp=points@rotation.T+pos;cells=np.round((wp-origin)/resolution).astype(int)
    occupied={(int(a),int(b)) for a,b in cells if 0<=a<shape[0] and 0<=b<shape[1]}
    grid=np.zeros(shape,dtype=bool)
    for cell in occupied:grid[cell]=True
    clearance=distance_transform_edt(~grid)*resolution;blocked=clearance<.12
    blocked[:int(round((-.8-origin[0])/resolution)),:]=True;blocked[int(round((.2-origin[0])/resolution))+1:,:]=True
    start=tuple(np.round((pos-origin)/resolution).astype(int))
    if arrival_time is not None:
     command(0,0)
     if sum(stamp>=arrival_time for stamp in tracker.verify_stamps)>=2 and elapsed-tracker.last_seen<tracker.max_result_age:
      arrival_confirmed=True;reason='goal_reached';break
     if clearance[start]<.12 or blocked[start]:reason='arrived_scan_blocked';break
     if elapsed-arrival_time>=8. or scan_index>=4:reason='arrived_target_unconfirmed';break
     offsets=[0.,math.radians(25),math.radians(-25),0.]
     desired=math.atan2(tracker.anchor[1]-pos[1],tracker.anchor[0]-pos[0])+offsets[scan_index]
     error=(desired-yaw+math.pi)%(2*math.pi)-math.pi
     w=float(np.clip(1.5*error,-.35,.35))
     if abs(error)<math.radians(4):
      w=0.
      if scan_hold is None:scan_hold=elapsed
      if elapsed-scan_hold>=.7:scan_index+=1;scan_hold=None
     else:scan_hold=None
     command(0,w);scan_events.append(dict(time_s=elapsed,v_mps=0.,w_radps=w,heading_error_deg=math.degrees(error),sweep_index=scan_index,clearance_m=float(clearance[start])))
     continue
    chosen,route,parking_detail=choose_parking(blocked,origin,resolution,pos,tracker.anchor,parking_goal)
    found=chosen is not None
    if found:
     if parking_goal is None or np.linalg.norm(chosen-parking_goal)>.001:
      parking_events.append(dict(time_s=elapsed,goal=chosen.tolist(),previous=parking_goal.tolist() if parking_goal is not None else None,**parking_detail));best=float('inf');progress_time=now
     parking_goal=chosen;goal=chosen.copy();dist=float(np.linalg.norm(goal-pos))
     goal_heading=(math.atan2(goal[1]-pos[1],goal[0]-pos[0])-yaw+math.pi)%(2*math.pi)-math.pi
     observation=build_observation(sectors,rates,previous_action,dist,goal_heading)
     with torch.no_grad():raw=actor(observation).cpu().numpy()[0]
     requested_v=-.10+(float(raw[0])+1)*.35/2;requested_w=.8*float(raw[1])
    finish=tuple(np.round((goal-origin)/resolution).astype(int));cost=range(parking_detail.get('reachable_cells',0))
    map_id=len(map_log)
    np.savez_compressed(folder/'maps'/f'{map_id:04d}.npz',occupied=grid,blocked=blocked,clearance=clearance,origin=origin,resolution=resolution,robot=pos,goal=goal,points=wp)
    map_log.append(dict(id=map_id,time_s=elapsed,found=found,start=[int(x) for x in start],finish=[int(x) for x in finish],start_blocked=bool(blocked[start]),goal_blocked=bool(blocked[finish]),start_clearance_m=float(clearance[start]),goal_clearance_m=float(clearance[finish]),visited=len(cost),robot=pos.tolist(),goal=goal.tolist(),yaw_rad=yaw,frame_id=tracker.last_frame))
    if not found:reason='no_reachable_parking';break
    target=route[min(6,len(route)-1)];local=rotation.T@(target-pos);angle=math.atan2(local[1],local[0]);previous=angle
    # Rotate before advancing; the inflated map accounts for the circular footprint.
    v=.22*max(0,math.cos(angle)) if abs(angle)<math.radians(35) else 0.;w=float(np.clip(2*angle,-.55,.55));free=float(clearance[start])
    # The validated Isaac map and 12 cm collision envelope define the safety envelope.
    # PPO may control only when its short swept arc is clear and points along the A-star route.
    pv=float(np.clip(requested_v,0,.22));pw=float(np.clip(requested_w,-.55,.55))
    # Preserve PPO steering; lift forward speed only on a straight, route-aligned segment.
    cruise_boost=bool(requested_v>.15 and abs(pw)<.1 and abs(angle)<math.radians(10))
    if cruise_boost:pv=.22
    ahead=pos.copy();direction=yaw;arc_safe=True
    for _ in range(8):
     direction+=pw*.1;ahead+=pv*.1*np.array([math.cos(direction),math.sin(direction)])
     cell=np.round((ahead-origin)/resolution).astype(int)
     if not(0<=cell[0]<shape[0] and 0<=cell[1]<shape[1]) or clearance[tuple(cell)]<.12:
      arc_safe=False;break
    # A large disagreement with the route indicates that the Gazebo-trained policy
    # would enter a side room or obstacle region. Use the known Isaac controller.
    route_agreement=abs((pw*.8-angle+math.pi)%(2*math.pi)-math.pi)<math.radians(25)
    selected='policy' if arc_safe and route_agreement else 'isaac_route'
    # Low-speed final approach uses the continuous goal, avoiding grid snapping
    # and PPO overshoot around a tiny remaining position error. Same 4 cm tolerance.
    terminal_clear=True
    for point in np.linspace(pos,goal,20):
     cell=np.round((point-origin)/resolution).astype(int)
     if not(0<=cell[0]<shape[0] and 0<=cell[1]<shape[1]) or clearance[tuple(cell)]<.12:
      terminal_clear=False;break
    if dist<.30 and terminal_clear:
     delta=rotation.T@(goal-pos);terminal_angle=math.atan2(delta[1],delta[0])
     v=min(.07,.8*dist)*max(0.,math.cos(terminal_angle)) if abs(terminal_angle)<math.radians(25) else 0.
     w=float(np.clip(2*terminal_angle,-.4,.4));selected='terminal_approach';terminal_decisions+=1
    elif selected=='policy':v,w=pv,pw;policy_decisions+=1
    else:route_fallbacks+=1
    command(v,w)
    control_events.append({'time_s':elapsed,'selection':selected,'v_mps':v,'w_radps':w,'goal':goal.tolist(),'visual_age_s':elapsed-tracker.last_seen,'frame_id':tracker.last_frame})
    previous_action=np.asarray([np.clip(2*(v+.1)/.35-1,-1,1),np.clip(w/.8,-1,1)],dtype=np.float32)
    history.append(dict(time_s=now-begin,x=float(pos[0]),y=float(pos[1]),yaw_rad=yaw,goal_distance_m=dist,heading_deg=math.degrees(angle),free_distance_m=free,depth_age_s=now-depth_fresh,v_mps=v,w_radps=w,selection=selected,actor_action=raw.tolist(),actor_requested=[requested_v,requested_w],cruise_boost=cruise_boost,arc_safe=arc_safe,route_agreement=route_agreement))
    if not -.04<tr[2]<.12:reason='left_floor';break
   if now-fresh>.6:reason='stale_scan';break
   if record and now>=next_capture:
    index=len(captures);path=folder/'frames'/f'{index:05d}.png'
    from PIL import Image
    Image.fromarray(np.array(ra.get_data())).save(path)
    captures.append({'file':path.name,'simulation_time_s':now-begin});next_capture=now+.2
  command(0,0);stop_position=body.get_transforms().copy()[0,:3].tolist();stop_time=sim_clock[0]-begin
  await frames(60);final=body.get_transforms().copy()[0,:3].tolist()
  drift=math.dist(stop_position,final)
  blocked=reason in ['no_safe_gap','blocked_no_progress'] and final[1]<-2.25
  expected_stop=reason in ['no_map_path','blocked_no_progress','no_safe_gap'] and final[1]<-1.98
  passed=(expected_stop if blocked_case else reason=='goal_reached') and max_force<=.1 and drift<.03
  await capture_viewport_to_file(vp,str(folder/'final.png')).wait_for_result()
 except Exception:
  reason='runtime_error';raise
 finally:
  command(0,0);t.pause();t.commit();ra.detach([rp]);da.detach([rp]);rp.destroy()
  report=dict(detector_variant='rotation_0_minus90_plus90',vision_result_max_age_s=tracker.max_result_age,parking_events=parking_events,scan_events=scan_events,parking_radius_m=.28,max_parking_radius_m=.65,scan_budget_s=8.,navigation_reached=arrival_time is not None,arrival_time_s=arrival_time,arrival_visual_confirmed=arrival_confirmed,static_target=True,static_goal=False,map_diagnostics=map_log,task='approach_any_trash',accepted_target_observations=tracker.accepted,layout_id=layout['id'],layout_mode=layout['mode'],controller_version="v2-continuous-terminal",terminal_decisions=terminal_decisions,online_perception=True,tracker_events=tracker.events,goal_updates=tracker.updates,perception_log=perception_log,control_events=control_events,run_folder=str(folder),sampling_note='RGB/depth/pose captured during brief physics pauses; inference runs concurrently with navigation. Not a hardware real-time benchmark.',case=name,seed=seed,expected_outcome="safe_stop" if blocked_case else "goal_reached",passed=locals().get('passed',False),reason=reason,goal=goal.tolist(),obstacles=CASES[name],final=locals().get('final'),duration_s=locals().get('stop_time'),braking_drift_m=locals().get('drift'),max_contact_force_n=max_force,contact_body_count=contact.sensor_count,monitored_colliders=filters,trajectory=history,video_frames=captures,localization='simulator ground truth',depth_obstacle_grid_counts=depth_counts,depth_ground_threshold_m=.012,depth_memory_seconds=3,planner='PPO commands inside Isaac depth+LiDAR A-star corridor with 12 cm collision envelope; route fallback',policy_decisions=policy_decisions,route_fallbacks=route_fallbacks,actor_weight_sha256=digest)
  (folder/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in report.items() if k not in ['trajectory','video_frames','monitored_colliders','perception_log','control_events']}))
 return report


async def online_suite():
 results=[]
 try:
  for layout in BENCHMARK['layouts']:
   if layout['id'] not in ['05','08','09','10']:continue
   name=layout['target'];r=await run_case(layout,name=name);results.append({k:r[k] for k in ['layout_id','layout_mode','case','passed','reason','duration_s','policy_decisions','route_fallbacks','terminal_decisions','max_contact_force_n','goal_updates','run_folder']})
   (ONLINE_ROOT/(RUN_ID+'-suite.json')).write_text(json.dumps(results,indent=2))
 except Exception:
  import traceback
  (ONLINE_ROOT/(RUN_ID+'-error.txt')).write_text(traceback.format_exc())
 finally:
  s=omni.usd.get_context().get_stage()
  for n in ['wheel_left_joint','wheel_right_joint']:
   UsdPhysics.DriveAPI.Get(s.GetPrimAtPath('/World/NavBot/Physics/'+n),'angular').GetTargetVelocityAttr().Set(0)
  omni.timeline.get_timeline_interface().pause()
builtins.navbot_suite_task=asyncio.ensure_future(online_suite())
