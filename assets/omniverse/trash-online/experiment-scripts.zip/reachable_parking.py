"""Select a reachable map cell around a remembered visual surface position."""
import heapq,math
import numpy as np

def choose_parking(blocked,origin,resolution,robot,target,previous=None,radius=.28,max_radius=.65):
 start=tuple(np.round((robot-origin)/resolution).astype(int));shape=blocked.shape
 if not(0<=start[0]<shape[0] and 0<=start[1]<shape[1]) or blocked[start]:return None,[],{'reason':'start_blocked'}
 costs={start:0.};parents={};queue=[(0.,start)]
 while queue:
  cost,cell=heapq.heappop(queue)
  if cost>costs[cell]:continue
  for dx,dy in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]:
   q=(cell[0]+dx,cell[1]+dy)
   if not(0<=q[0]<shape[0] and 0<=q[1]<shape[1]) or blocked[q]:continue
   if dx and dy and (blocked[cell[0]+dx,cell[1]] or blocked[cell[0],cell[1]+dy]):continue
   new=cost+math.hypot(dx,dy)*resolution
   if new<costs.get(q,float('inf')):costs[q]=new;parents[q]=cell;heapq.heappush(queue,(new,q))
 selected=None;mode='default_ring'
 if previous is not None:
  q=tuple(np.round((previous-origin)/resolution).astype(int))
  if q in costs and np.linalg.norm(np.array(q)*resolution+origin-target)<=max_radius:selected=q;mode='retained'
 if selected is None:
  ring=[];outer=[]
  for q,c in costs.items():
   distance=float(np.linalg.norm(np.array(q)*resolution+origin-target))
   if abs(distance-radius)<=resolution*.8:ring.append((c,abs(distance-radius),q))
   elif radius+resolution*.8<distance<=max_radius:outer.append((distance,c,q))
  if ring:selected=min(ring)[2]
  elif outer:selected=min(outer)[2];mode='expanded_radius'
 if selected is None:return None,[],dict(reason='no_reachable_parking',reachable_cells=len(costs))
 route=[selected]
 while route[-1]!=start:route.append(parents[route[-1]])
 route.reverse();point=np.array(selected)*resolution+origin
 return point,np.array(route)*resolution+origin,dict(mode=mode,target_distance_m=float(np.linalg.norm(point-target)),path_length_m=costs[selected],reachable_cells=len(costs))
