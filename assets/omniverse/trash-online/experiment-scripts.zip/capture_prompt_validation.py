import asyncio,builtins,json,time
from pathlib import Path
import numpy as np
import omni.usd,omni.timeline,omni.kit.app
from pxr import Usd,UsdGeom,Gf
async def capture_validation():
 root=Path('C:/Users/User/Documents/ChatGPT/RL Navigation/outputs/trash-online');source=root/'20261001-095815-parkingscan-05-water_bottle_01';out=root/('prompt-validation-'+time.strftime('%Y%m%d-%H%M%S'));out.mkdir()
 app=omni.kit.app.get_app();ctx=omni.usd.get_context();tl=omni.timeline.get_timeline_interface()
 async def frames(n):
  for _ in range(n):await app.next_update_async()
 tl.stop();tl.commit();await frames(10);await ctx.open_stage_async(str(source/'scene.usda'));await frames(60);s=ctx.get_stage();assert any('approved_appearance.usda' in x for x in s.GetRootLayer().subLayerPaths)
 def place(path,xy,rot):
  prim=s.GetPrimAtPath(path);x=UsdGeom.Xformable(prim);x.ClearXformOpOrder();shift=x.AddTranslateOp();shift.Set(Gf.Vec3d(0));x.AddRotateXYZOp().Set(Gf.Vec3f(*rot));b=UsdGeom.BBoxCache(Usd.TimeCode.Default(),['default','render','proxy']).ComputeWorldBound(prim).ComputeAlignedRange();lo=b.GetMin();hi=b.GetMax();shift.Set(Gf.Vec3d(xy[0]-(lo[0]+hi[0])/2,xy[1]-(lo[1]+hi[1])/2,.005-lo[2]))
 for kind,xy in [('book',[-.05,-2.2]),('shoe',[-.6,-2.45])]:
  path='/World/Trash/distractor_'+kind;UsdGeom.Xform.Define(s,path).GetPrim().GetReferences().AddReference('C:/Users/User/Documents/simforge_assets/'+kind+'_01/usd/'+kind+'_01.usda');place(path,xy,[0,0,0])
 meta=json.loads((source/'requests/00040.json').read_text());matrix=np.array(meta['camera_to_world']);center=np.array([-.538,-1.825]);direction=matrix[3,:2]-center;direction/=np.linalg.norm(direction)
 camera=UsdGeom.Camera.Define(s,'/World/RotationValidationCamera');camera.CreateFocalLengthAttr(12);camera.CreateHorizontalApertureAttr(20.14);camera.CreateVerticalApertureAttr(15.105);camera.CreateClippingRangeAttr(Gf.Vec2f(.04,4));x=UsdGeom.Xformable(camera);x.ClearXformOpOrder();op=x.AddTransformOp()
 import omni.replicator.core as rep
 from PIL import Image
 product=rep.create.render_product(camera.GetPath(),(640,480));rgb=rep.AnnotatorRegistry.get_annotator('rgb');rgb.attach([product]);depth=rep.AnnotatorRegistry.get_annotator('distance_to_image_plane');depth.attach([product]);records=[];tl.play();tl.commit();await frames(60)
 try:
  specs=[(angle,d,False) for angle in [-145,-85,-20,40,100] for d in [.40,.60,.85,1.10]]+[(0,d,True) for d in [.35,.55,.8,1.05,1.25,1.45]]
  for i,(angle,d,negative) in enumerate(specs):
   for name in ['milk_bottle_01','water_bottle_01','paper_wad_01']:s.GetPrimAtPath('/World/Trash/'+name).SetActive(not negative)
   if not negative:place('/World/Trash/water_bottle_01',center,[90,0,angle])
   pose=matrix.copy();pose[3,:2]=center+direction*d;op.Set(Gf.Matrix4d(*pose.flatten().tolist()));await frames(24)
   stem=f'{i:03d}';pixels=np.array(rgb.get_data());assert pixels.shape[:2]==(480,640);Image.fromarray(pixels).save(out/(stem+'.png'));np.save(out/(stem+'.npy'),np.array(depth.get_data()).squeeze());cache=UsdGeom.BBoxCache(Usd.TimeCode.Default(),['default','render','proxy']);bounds={}
   for prim in s.GetPrimAtPath('/World/Trash').GetChildren():
    if prim.IsActive():
     b=cache.ComputeWorldBound(prim).ComputeAlignedRange();bounds[prim.GetName()]=dict(min=list(b.GetMin()),max=list(b.GetMax()))
   records.append(dict(stem=stem,angle=angle,distance_m=d,negative=negative,bounds=bounds,camera_to_world=pose.tolist(),fx=meta['fx'],fy=meta['fy']))
  (out/'manifest.json').write_text(json.dumps(dict(notes='Four fixed prompt/rotation variants compared on fresh yaw/distance combinations. Same asset and room, not independent real-world validation.',records=records),indent=2))
 except Exception:
  import traceback
  (out/'error.txt').write_text(traceback.format_exc())
 finally:rgb.detach([product]);depth.detach([product]);product.destroy();tl.pause()
builtins.rotation_validation_task=asyncio.ensure_future(capture_validation())
