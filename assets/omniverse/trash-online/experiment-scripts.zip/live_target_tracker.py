"""Conservative visual target tracking; no scene-object coordinates are used."""
import numpy as np

class TargetTracker:
 def __init__(self,label):
  self.label=label;self.samples=[];self.anchor=None;self.goal=None;self.direction=None
  self.last_seen=None;self.last_frame=-1;self.confirmed=False;self.state='acquiring'
  self.events=[];self.updates=0;self.required=3;self.loss_timeout=.8;self.max_result_age=.6
 def ingest(self,result,robot_xy,now):
  if result['frame_id']<=self.last_frame:return
  self.last_frame=result['frame_id'];stamp=result['simulation_time_s']
  if now-stamp>self.max_result_age:
   self.events.append({'event':'stale_result_rejected','time_s':now,'age_s':now-stamp});return
  valid=[d for d in result['detections'] if d['class']==self.label and d.get('valid_depth_pixels',0)>=9 and 'surface_median_world_xyz' in d]
  if self.anchor is not None:valid=[d for d in valid if np.linalg.norm(np.array(d['surface_median_world_xyz'])[:2]-self.anchor)<.25]
  if not valid:
   self.samples=[];return
  d=max(valid,key=lambda x:x['confidence']);p=np.array(d['surface_median_world_xyz'])[:2]
  self.last_seen=stamp;self.samples.append(p);self.samples=self.samples[-self.required:]
  if len(self.samples)<self.required:return
  center=np.median(self.samples,axis=0)
  if max(np.linalg.norm(x-center) for x in self.samples)>.06:return
  if self.direction is None:
   delta=center-np.array(robot_xy);self.direction=delta/max(np.linalg.norm(delta),1e-6)
  proposal=center-.28*self.direction
  if self.goal is None or np.linalg.norm(proposal-self.goal)>.05:
   self.goal=proposal;self.updates+=1
   self.events.append({'event':'goal_initialized' if self.anchor is None else 'goal_updated','time_s':now,'goal':self.goal.tolist(),'surface':center.tolist(),'frame_id':result['frame_id']})
  if not self.confirmed:self.events.append({'event':'target_confirmed','time_s':now,'frame_id':result['frame_id']})
  self.anchor=center;self.confirmed=True;self.state='tracking'
 def allowed(self,now):
  if self.last_seen is not None and now-self.last_seen>self.loss_timeout:
   if self.confirmed:self.events.append({'event':'target_lost_stop','time_s':now});self.samples=[]
   self.confirmed=False;self.state='lost'
  return self.confirmed and self.goal is not None
