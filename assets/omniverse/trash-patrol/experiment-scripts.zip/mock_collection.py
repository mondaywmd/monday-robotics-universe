"""Simulation-only collection adapter. Scene identity is never fed back as a navigation goal."""
import math
from pxr import Usd,UsdGeom,UsdPhysics

def collect(stage,request):
 cache=UsdGeom.BBoxCache(Usd.TimeCode.Default(),['default','render','proxy']);matches=[]
 for prim in stage.GetPrimAtPath('/World/Trash').GetChildren():
  if not prim.GetName().startswith(('milk_bottle_','water_bottle_','paper_wad_')):continue
  if UsdGeom.Imageable(prim).ComputeVisibility()==UsdGeom.Tokens.invisible:continue
  box=cache.ComputeWorldBound(prim).ComputeAlignedRange();lo=box.GetMin();hi=box.GetMax()
  distance=math.sqrt(sum(max(lo[i]-request['target_xy'][i],0,request['target_xy'][i]-hi[i])**2 for i in [0,1]))
  if distance<.12:matches.append((distance,prim))
 if not matches:return dict(success=False,mode='mock',reason='no_matching_simulated_litter')
 _,prim=min(matches,key=lambda item:item[0])
 # Keep prim paths stable for contact reporting, while removing visual and physical presence.
 UsdGeom.Imageable(prim).MakeInvisible()
 for child in Usd.PrimRange(prim):
  if child.HasAPI(UsdPhysics.CollisionAPI):UsdPhysics.CollisionAPI(child).CreateCollisionEnabledAttr(False)
  if child.HasAPI(UsdPhysics.RigidBodyAPI):UsdPhysics.RigidBodyAPI(child).CreateRigidBodyEnabledAttr(False)
 return dict(success=True,mode='mock',request_id=request['request_id'],removed_prim=str(prim.GetPath()),reason='simulated_collection_acknowledged')
