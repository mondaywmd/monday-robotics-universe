from pathlib import Path
import json,math
from PIL import Image,ImageDraw,ImageFont
import imageio_ffmpeg

ROOT=Path(__file__).resolve().parents[1]/'outputs/trash-online'
FONT='C:/Windows/Fonts/arial.ttf'
regular=ImageFont.truetype(FONT,18);small=ImageFont.truetype(FONT,15);title=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',22)

def compose(folder,entry,events,total):
 frame_id=entry['frame_id'];stamp=entry['captured_s'];left=Image.open(folder/'results'/f'{frame_id:05d}.jpg').convert('RGB');right=Image.open(folder/'third'/f'{frame_id:05d}.jpg').convert('RGB')
 meta=json.loads((folder/'requests'/f'{frame_id:05d}.json').read_text());acks=[e for e in events if e['event']=='collection_result' and e.get('success') and e['time_s']<=stamp]
 canvas=Image.new('RGB',(1280,624),'#0a1717');draw=ImageDraw.Draw(canvas)
 draw.text((22,13),'NAVBOT  /  PATROL + MOCK COLLECTION',font=title,fill='#f0f4e9');draw.text((946,17),'SAME RUN  /  SYNCHRONIZED',font=small,fill='#b8d2c6')
 draw.text((22,49),'01  ROBOT RGB + ONLINE YOLOE',font=regular,fill='#bce384');draw.text((664,49),'02  THIRD-PERSON FOLLOW CAMERA',font=regular,fill='#bce384')
 # Replace only the worker's existing header bar; retain actual detector boxes below it.
 ld=ImageDraw.Draw(left);ld.rectangle((0,0,640,60),fill='#102324');ld.text((12,9),'Camera detections used by the running controller',font=small,fill='#e5eee8');ld.text((12,33),'YOLOE zero-shot + rotation augmentation',font=small,fill='#b2c7bc')
 canvas.paste(left,(0,78));canvas.paste(right,(640,78));draw=ImageDraw.Draw(canvas);draw.line((640,78,640,558),fill='#abc3b4',width=2)
 state={'patrol':'Patrolling','approach_trash':'Approaching litter','patrol_scan':'Looking around'}.get(meta['tracker_state'],meta['tracker_state'])
 draw.text((22,578),f'SIM  {stamp:6.1f} s     |     {state}',font=regular,fill='white')
 draw.text((530,578),f'MOCK COLLECTED  {len(acks)} / {total}',font=title,fill='#bce384')
 if acks and stamp-acks[-1]['time_s']<2.5:draw.text((929,581),'COLLECTION ACKNOWLEDGED',font=small,fill='#bce384')
 else:draw.text((966,581),'No physical grasping',font=small,fill='#b2c7bc')
 return canvas

if __name__=='__main__':
 folder=sorted(ROOT.glob('*-patrol-dual-01-*'))[-1];r=json.loads((folder/'report.json').read_text());pairs={p['frame_id']:p for p in r['paired_frames']};logs=r['perception_log'];events=r['mission_events'];total=len(json.loads((folder/'layout.json').read_text())['layout']['objects'])
 output=folder/'patrol-split-screen.mp4';writer=imageio_ffmpeg.write_frames(str(output),(1280,624),fps=20,codec='libx264',pix_fmt_out='yuv420p',output_params=['-crf','20','-movflags','+faststart']);writer.send(None);frames=0
 try:
  for i,e in enumerate(logs):
   assert abs(pairs[e['frame_id']]['simulation_time_s']-e['captured_s'])<1e-6
   im=compose(folder,e,events,total)
   end=logs[i+1]['captured_s'] if i+1<len(logs) else max(e['captured_s']+.2,r['duration_s'])
   count=max(1,round(end*20)-round(e['captured_s']*20))
   for _ in range(count):writer.send(im.tobytes());frames+=1
   if i in [0,len(logs)//2,len(logs)-1]:im.save(folder/f'split-preview-{i}.jpg',quality=94)
  card=Image.new('RGB',(1280,624),'#0a1717');d=ImageDraw.Draw(card);acks=[e for e in events if e['event']=='collection_result' and e.get('success')]
  d.text((65,120),f'{len(acks)} / {total} MOCK COLLECTIONS',font=ImageFont.truetype(FONT,46),fill='#bce384')
  stop_label={'blocked_no_progress':'Safe stop: no navigation progress on patrol return','patrol_waypoint_unreachable':'Safe stop: patrol return route unavailable','patrol_complete':'Patrol route completed'}.get(r['reason'],r['reason']);d.text((65,205),stop_label,font=title,fill='white');d.text((65,256),f'Max sampled contact force: {r["max_contact_force_n"]:.3f} N',font=title,fill='white')
  d.text((65,332),'Simulated pickup acknowledgement; no arm or physical grasp.',font=regular,fill='#baccc2');d.text((65,369),'Collection success and complete patrol coverage are separate outcomes.',font=regular,fill='#baccc2')
  for _ in range(60):writer.send(card.tobytes());frames+=1
 finally:writer.close()
 mid=logs[len(logs)//2];compose(folder,mid,events,total).save(folder/'split-poster.jpg',quality=94)
 audit=dict(run=folder.name,paired_samples=len(logs),timestamp_mismatch_count=0,render_fps=20,output_frames=frames,output_duration_s=frames/20,end_card_s=3,notes='Same source snapshots for both views. Actual online detector outputs. Frames held to simulation timestamps; physics capture pauses omitted. Not hardware real-time footage.')
 (folder/'video-sync-audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2))
