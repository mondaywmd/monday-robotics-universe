import math
import numpy as np

def swept_clear(blocked,origin,resolution,position,yaw,v,w,horizon=.8):
 """Check every executed action, including route/terminal fallbacks, on the same inflated map."""
 p=np.array(position,float).copy();direction=yaw
 for i in range(int(horizon/.025)+1):
  cell=np.round((p-origin)/resolution).astype(int)
  if not(0<=cell[0]<blocked.shape[0] and 0<=cell[1]<blocked.shape[1]) or blocked[tuple(cell)]:return False
  direction+=w*.025;p+=v*.025*np.array([math.cos(direction),math.sin(direction)])
 return True
