"""Visual-only litter memory and a waypoint patrol state machine."""
import numpy as np

class PatrolMission:
 def __init__(self,waypoints):
  self.waypoints=[np.array(p,float) for p in waypoints];self.index=0;self.targets=[];self.active=None;self.events=[];self.accepted=[];self.updates=0;self.last_frame=-1;self.last_seen=-1e9;self.max_result_age=1.2;self.verify_stamps=[];self.state='patrol';self.confirmed=True
 @property
 def anchor(self):return None if self.active is None else np.array(self.active['position'])
 @property
 def goal(self):return self.anchor if self.active else (self.waypoints[self.index].copy() if self.index<len(self.waypoints) else None)
 def allowed(self,now):return self.goal is not None
 def ingest(self,result,robot_xy,now):
  if result['frame_id']<=self.last_frame:return
  self.last_frame=result['frame_id'];stamp=result['simulation_time_s']
  if now-stamp>self.max_result_age:return
  matched=set()
  for d in sorted(result['detections'],key=lambda d:d['confidence'],reverse=True):
   if d['class'] not in ['milk jug','plastic water bottle','crumpled tissue paper'] or d.get('valid_depth_pixels',0)<9:continue
   xyz=np.array(d['surface_median_world_xyz']);p=xyz[:2]
   if not np.isfinite(xyz).all() or not(-.02<xyz[2]<.32):continue
   # The mission covers the corridor and living room, not adjacent rooms/walls.
   if not ((-.8<=p[0]<=.2 and -3.5<=p[1]<=1.35) or (-4.1<=p[0]<=.2 and 1.30<=p[1]<=4.4)):continue
   nearby=[t for t in self.targets if np.linalg.norm(p-np.array(t['position']))<.22]
   if nearby:target=min(nearby,key=lambda t:np.linalg.norm(p-np.array(t['position'])))
   else:
    target=dict(id=len(self.targets)+1,position=p.tolist(),status='candidate',observations=[],last_seen=stamp);self.targets.append(target)
   if target['id'] in matched:continue
   matched.add(target['id']);target['last_seen']=stamp
   if target['status']=='candidate':
    target['observations']=[o for o in target['observations'] if stamp-o['stamp']<3.]
    target['observations'].append(dict(stamp=stamp,position=p.tolist(),frame=result['frame_id']))
    points=np.array([o['position'] for o in target['observations']]);center=points.mean(0)
    if len(points)>=3 and np.max(np.linalg.norm(points-center,axis=1))<.06:
     target['position']=center.tolist();target['status']='pending';self.events.append(dict(event='trash_confirmed',time_s=now,target_id=target['id'],position=center.tolist()));self.updates+=1
   if target is self.active and np.linalg.norm(p-self.anchor)<.12:
    self.last_seen=stamp;self.verify_stamps.append(stamp)
   self.accepted.append(dict(frame_id=result['frame_id'],time_s=now,target_id=target['id'],world_xyz=xyz.tolist(),original_class=d['class']))
 def select(self,robot_xy,now):
  if self.active:return False
  pending=[t for t in self.targets if t['status']=='pending']
  if not pending:return False
  self.active=min(pending,key=lambda t:np.linalg.norm(np.array(t['position'])-robot_xy));self.active['status']='approaching';self.last_seen=self.active['last_seen'];self.verify_stamps=[];self.state='approach_trash';self.events.append(dict(event='patrol_interrupted',time_s=now,target_id=self.active['id'],resume_waypoint=self.index));return True
 def finish_target(self,now,status):
  assert self.active is not None
  self.active['status']=status;self.events.append(dict(event='target_finished',time_s=now,target_id=self.active['id'],status=status));self.active=None;self.verify_stamps=[];self.last_seen=-1e9;self.state='patrol';self.events.append(dict(event='patrol_resumed',time_s=now,waypoint=self.index))
 def waypoint_reached(self,now):
  self.events.append(dict(event='waypoint_reached',time_s=now,waypoint=self.index,position=self.waypoints[self.index].tolist()));self.index+=1
  if self.index==len(self.waypoints):self.state='patrol_complete'
