"""Reuse a reachable retained goal with A*, keeping the original parking fallback."""
import heapq,math
import numpy as np
from reachable_parking import choose_parking as full_parking

def astar(blocked,start,finish):
 shape=blocked.shape
 if any(not(0<=q[0]<shape[0] and 0<=q[1]<shape[1]) or blocked[q] for q in [start,finish]):return [],0
 costs={start:0.};parent={};queue=[(math.dist(start,finish),0.,start)]
 while queue:
  _,cost,cell=heapq.heappop(queue)
  if cost>costs[cell]:continue
  if cell==finish:
   route=[cell]
   while route[-1]!=start:route.append(parent[route[-1]])
   return route[::-1],len(costs)
  for dx,dy in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]:
   q=cell[0]+dx,cell[1]+dy
   if not(0<=q[0]<shape[0] and 0<=q[1]<shape[1]) or blocked[q]:continue
   if dx and dy and (blocked[cell[0]+dx,cell[1]] or blocked[cell[0],cell[1]+dy]):continue
   new=cost+math.hypot(dx,dy)
   if new<costs.get(q,float('inf')):costs[q]=new;parent[q]=cell;heapq.heappush(queue,(new+math.dist(q,finish),new,q))
 return [],len(costs)

def choose_parking(blocked,origin,resolution,robot,target,previous=None,radius=.28,max_radius=.65):
 point=previous if previous is not None else target if radius==0 else None
 if point is not None and np.linalg.norm(np.array(point)-target)<=max_radius:
  start=tuple(np.round((robot-origin)/resolution).astype(int));finish=tuple(np.round((point-origin)/resolution).astype(int));route,searched=astar(blocked,start,finish)
  if route:
   world=np.array(route)*resolution+origin
   return world[-1],world,dict(mode='retained_astar' if previous is not None else 'patrol_astar',target_distance_m=float(np.linalg.norm(world[-1]-target)),path_length_m=float(np.linalg.norm(np.diff(world,axis=0),axis=1).sum()),searched_cells=searched,search_method='astar')
 return full_parking(blocked,origin,resolution,robot,target,previous,radius,max_radius)
