"""Local RGB optical orientation only. No ROS, actuation, or implicit TF changes."""
import json
from pathlib import Path
import numpy as np
import cv2

class UnsupportedPose(ValueError):
    pass

def orientation(joint_rad, *, approach_verified=False, experimental=False, config_path=None):
    """Return R_base_from_rgb_optical. Translation and absolute yaw are NOT calibrated.
    approach_verified must describe verified motion history, not merely matching q.
    Default permits only independently tested targets and the fitted baseline.
    """
    cfg=json.loads((Path(config_path) if config_path else Path(__file__).with_name('calibration.json')).read_text())
    q=np.asarray(joint_rad,dtype=float);q0=np.asarray(cfg['baseline_joint_rad'])
    if q.shape!=(6,) or not np.isfinite(q).all():raise ValueError('Expected six finite arm angles in radians')
    if not approach_verified:raise UnsupportedPose('Unknown or reverse approach history')
    tol=cfg['pose_match_tolerance_rad']
    if np.max(abs(q-q0))<=tol:return np.array(cfg['baseline_rotation_base_from_rgb'])
    if not experimental:
        for pose in cfg['validated_targets']:
            if np.max(abs(q-np.array(pose['joint_rad'])))<=tol:return np.array(pose['rotation_base_from_rgb'])
        raise UnsupportedPose('Pose not independently validated; no correction returned')
    if np.max(abs(q[4:]-q0[4:]))>tol:raise UnsupportedPose('Tool joint configuration changed')
    R=np.array(cfg['baseline_rotation_base_from_rgb'])
    for seg in cfg['segments']:
        d=float(q[seg['joint']]-q0[seg['joint']]);knots=sorted(seg['knots'],key=lambda k:k['delta_rad'])
        if d<knots[0]['delta_rad']-tol or d>knots[-1]['delta_rad']+tol:raise UnsupportedPose('No extrapolation')
        d=np.clip(d,knots[0]['delta_rad'],knots[-1]['delta_rad'])
        for a,b in zip(knots,knots[1:]):
            if a['delta_rad']<=d<=b['delta_rad']:
                w=(d-a['delta_rad'])/(b['delta_rad']-a['delta_rad'])
                A=cv2.Rodrigues(np.array(a['rotation_vector_rad'],float))[0]
                B=cv2.Rodrigues(np.array(b['rotation_vector_rad'],float))[0]
                R=R@A@cv2.Rodrigues(cv2.Rodrigues(A.T@B)[0]*w)[0]
                break
    return R

def rotate_vectors(vectors_rgb, joint_rad, **kwargs):
    """Rotate optical-frame direction/displacement vectors. NOT absolute point positions."""
    v=np.asarray(vectors_rgb,dtype=float)
    if v.ndim!=2 or v.shape[1]!=3:raise ValueError('Expected Nx3 vectors')
    return v@orientation(joint_rad,**kwargs).T
