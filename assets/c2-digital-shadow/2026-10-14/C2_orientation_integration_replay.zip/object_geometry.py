"""Experimental visible-surface estimate, never a grasp/navigation command."""
import base64
import numpy as np
import cv2
from camera_compensation import corrected_points
from orientation_integration import convert_directions

def estimate(mask,depth,info,transform,*,orientation_context=None):
    if depth['encoding'] not in ('mono16','16UC1'):return {'reason':'不支持的深度格式'}
    h,w=depth['height'],depth['width']
    if (info['height'],info['width'])!=(h,w):return {'reason':'标定尺寸不匹配'}
    z=np.ndarray((h,w),dtype='>u2' if depth['is_bigendian'] else '<u2',buffer=base64.b64decode(depth['data']),strides=(depth['step'],2)).astype(float)/1000
    mask=cv2.resize(mask.astype(np.uint8),(w,h),interpolation=cv2.INTER_NEAREST)
    mask=cv2.erode(mask,np.ones((7,7),np.uint8))>0
    valid=mask & np.isfinite(z) & (z>=.15) & (z<=4)
    n=int(valid.sum());area=int(mask.sum())
    if n<60 or n/max(area,1)<.35:return {'reason':'有效深度不足'}
    median=float(np.median(z[valid]));mad=float(np.median(abs(z[valid]-median)))
    valid &= abs(z-median)<max(.04,2.5*mad)
    yy,xx=np.where(valid);zz=z[valid]
    k=info['k'];fx,fy,cx,cy=k[0],k[4],k[2],k[5]
    if min(fx,fy)<=0:return {'reason':'相机标定无效'}
    # SDK aligned cloud is empirically RGB pinhole, with no additional undistortion.
    points=np.stack(((xx-cx)*zz/fx,(yy-cy)*zz/fy,zz),axis=1)
    x,y,zq,qw=transform['xyzw'];norm=np.linalg.norm([x,y,zq,qw])
    if abs(norm-1)>.01:return {'reason':'坐标变换无效'}
    r=np.array([[1-2*(y*y+zq*zq),2*(x*y-zq*qw),2*(x*zq+y*qw)],[2*(x*y+zq*qw),1-2*(x*x+zq*zq),2*(y*zq-x*qw)],[2*(x*zq-y*qw),2*(y*zq+x*qw),1-2*(x*x+y*y)]])
    body=points@r.T+np.array(transform['translation'])
    pos=np.median(body,axis=0)
    candidate=np.median(corrected_points(points,r,np.array(transform['translation'])),axis=0)
    local_orientation=convert_directions([np.median(points,axis=0)],orientation_context)
    return {'local_orientation':local_orientation,'status':'experimental','base_xyz_m':pos.tolist(),'candidate_base_xyz_m':candidate.tolist(),'candidate_status':'provisional_read_only','front_reference_x_m':.136,'original_front_gap_m':float(pos[0]-.136),'candidate_front_gap_m':float(candidate[0]-.136),'camera_xyz_m':np.median(points,axis=0).tolist(),'camera_depth_m':median,'support':len(points),'valid_fraction':n/max(area,1),'depth_mad_m':mad,'meaning':'visible surface median, not object center or grasp pose'}
