const $=id=>document.getElementById(id);
const names={'/scan':'scan','/camera/color/image_raw':'color','/camera/depth/image_raw':'depth'};
let sequence=0,lastScan,lastDepth,latest={},connected=false,serverNow=Date.now(),receivedAt=Date.now();
let depthTarget=null;
function refreshDistances(stale){
 const readings=lastScan&&!stale?sectorReadings(lastScan):[null,null,null];
 $('frontDistances').innerHTML=readings.map((v,i)=>`<div class="distance-card"><span>${['左前','正前','右前'][i]}</span><strong>${v?.nearest!=null?v.nearest.toFixed(2)+' 米':'未知'}</strong><small>${stale?'数据过期':!v?'等待数据':v.count?'有效回波 '+v.count+' 点':'无有效回波'}</small></div>`).join('');
}
// Fixed transform verified against live /tf_static and manufacturer C2 URDF.
function bodyPoint(range,angle){return {x:0.0782723573-range*Math.cos(angle),y:-range*Math.sin(angle)};}
function sectorReadings(m){const sectors=[[],[],[]];m.ranges.forEach((v,i)=>{if(typeof v!=='number'||!Number.isFinite(v)||v<m.range_min||v>m.range_max||v<=0)return;const p=bodyPoint(v,m.angle_min+i*m.angle_increment),a=Math.atan2(p.y,p.x)*180/Math.PI;if(a < -45||a>45)return;const k=a>15?0:a< -15?2:1;sectors[k].push(Math.hypot(p.x,p.y));});return sectors.map(v=>({count:v.length,nearest:v.length?Math.min(...v):null}));}
function updateDepthTarget(){if(!lastDepth||!depthTarget)return;const {w,h,values}=lastDepth,{x,y}=depthTarget,vals=[];for(let j=Math.max(0,y-4);j<=Math.min(h-1,y+4);j++)for(let i=Math.max(0,x-4);i<=Math.min(w-1,x+4);i++){const v=values[j*w+i];if(Number.isFinite(v)&&v>0)vals.push(v);}vals.sort((a,b)=>a-b);const g=$('depth').getContext('2d');g.strokeStyle='white';g.lineWidth=2;g.strokeRect(x-5,y-5,10,10);$('depthPick').textContent=`选定区域 (${x}, ${y})：${vals.length?vals[Math.floor(vals.length/2)].toFixed(3)+' 米':'未知（无有效深度）'} · 每帧更新 · 固定像素，非物体跟踪`;}
function bytes(data){return typeof data==='string'?Uint8Array.from(atob(data),c=>c.charCodeAt(0)):Uint8Array.from(data);}
let detectionSource=0;
async function detectionPoll(){
 let og=$('localOrientation');if(!og){og=document.createElement('p');og.id='localOrientation';og.className='note';$('detectLabels').after(og);}
 og.textContent='新方向补偿：等待有效数据；不提供已校准的物体坐标';
 try{const r=await fetch('/detection');const d=await r.json();
  if(d.status==='ready'){
   if(d.source_received_ms!==detectionSource){detectionSource=d.source_received_ms;$('detectImage').src=d.image;}
   const age=(Date.now()-d.source_received_ms)/1000;$('detectPanel').classList.toggle('stale',age>5);
   og.textContent=age>3?'新方向补偿：数据过期，未显示':d.detections.map(x=>{const o=x.position?.local_orientation;return x.label+'：'+(o?.status==='local_orientation_only'?'局部方向补偿已应用（位置与绝对朝向未校准）':o?.reason||'未应用新方向补偿');}).join(' ｜ ')||'新方向补偿：本帧没有可用目标';
   $('detectFresh').textContent=`${age>5?'结果过期':'最近识别帧'} · ${age.toFixed(1)} 秒前 · 推理 ${d.inference_s} 秒`;
   $('detectLabels').textContent=d.detections.length?d.detections.map(x=>{const p=x.position;return `${x.label} ${x.score.toFixed(2)}${age>5?' · 距离过期':p?.camera_depth_m?` · 相机深度 ${p.camera_depth_m.toFixed(2)} m（表面估计）`:` · ${p?.reason||'位置待核对'}`}`;}).join(' ｜ '):'本帧未检测到达到阈值的目标';
   let cg=$('candidateGeometry');if(!cg){cg=document.createElement('p');cg.id='candidateGeometry';cg.className='note';$('detectLabels').after(cg);}
   cg.textContent=age>3?'暂定补偿位置：数据过期，暂不显示':d.detections.map(x=>{const p=x.position;if(p?.candidate_status!=='provisional_read_only')return x.label+'：'+(p?.reason||'等待有效深度');return x.label+'：距车前沿（前向）约 '+(p.candidate_front_gap_m*100).toFixed(1)+' 厘米，原模型 '+(p.original_front_gap_m*100).toFixed(1)+' 厘米';}).join(' ｜ ')+(d.detections.length?'。暂定相机补偿；车前沿按模型估计，仅供观察，不是抓取位置。':'本帧没有可用目标');
   let vg=document.getElementById('vendorGeometry');if(!vg){vg=document.createElement('p');vg.id='vendorGeometry';vg.className='note';$('detectLabels').after(vg);}
   vg.textContent=age>3?'厂家模型位置：数据过期，暂不显示':d.detections.map(x=>{const v=x.vendor_estimate;if(v?.status!=='unvalidated_vendor_model')return x.label+'：'+(v?.reason||'等待位置计算');return x.label+'：厂家坐标 X/Y/Z '+v.xyz_m.map(n=>(n*100).toFixed(1)).join(' / ')+' 厘米；距模型末端 '+(v.distance_to_DH_endpoint_m*100).toFixed(1)+' 厘米';}).join(' ｜ ')+'。仅模型估计，未校准；不是夹爪接触点或抓取指令。';
  }else{if($('candidateGeometry'))$('candidateGeometry').textContent='暂定补偿位置：数据不可用';if($('vendorGeometry'))$('vendorGeometry').textContent='厂家模型位置：数据不可用';$('detectFresh').textContent=d.message||'等待识别';$('detectPanel').classList.add('stale');}
 }catch{if($('candidateGeometry'))$('candidateGeometry').textContent='暂定补偿位置：服务未连接';if($('vendorGeometry'))$('vendorGeometry').textContent='厂家模型位置：服务未连接';$('detectFresh').textContent='识别服务未连接';$('detectPanel').classList.add('stale');}
 finally{setTimeout(detectionPoll,700);}
}
detectionPoll();
function drawScan(m){lastScan=m;const c=$('scan'),g=c.getContext('2d'),r=Number($('radius').value),s=220/r,cx=320,cy=256;g.fillStyle='#0a1118';g.fillRect(0,0,640,512);g.strokeStyle='#334854';g.fillStyle='#b8cbd7';g.font='14px system-ui';
 for(let k=1;k<=5;k++){g.beginPath();g.arc(cx,cy,k*44,0,2*Math.PI);g.stroke();g.fillText((r*k/5).toFixed(1)+' m',cx+5,cy-k*44+15);}
 g.beginPath();g.moveTo(cx,20);g.lineTo(cx,492);g.moveTo(80,cy);g.lineTo(560,cy);g.stroke();let valid=0,nearest=Infinity;
 g.fillStyle='#64d9b8';m.ranges.forEach((v,i)=>{if(typeof v!=='number'||!Number.isFinite(v)||v<m.range_min||v>m.range_max||v<=0)return;valid++;nearest=Math.min(nearest,v);const p=bodyPoint(v,m.angle_min+i*m.angle_increment);if(Math.hypot(p.x,p.y)>r)return;g.fillRect(cx-p.y*s-1.5,cy-p.x*s-1.5,3,3);});
 g.fillStyle='#ffcb70';g.beginPath();g.moveTo(cx,cy-10);g.lineTo(cx-7,cy+7);g.lineTo(cx+7,cy+7);g.closePath();g.fill();g.fillText('车头',cx+10,20);g.fillText('左',65,cy-10);
 // Distances are rendered by the freshness timer, including after radius changes.
 $('scanMeta').textContent=`${m.header.frame_id} · ${valid}/${m.ranges.length} 个有效测距 · 最近回波 ${Number.isFinite(nearest)?nearest.toFixed(2)+' 米':'无'}（距雷达）`;
}
function drawImage(m,key){const c=$(key),w=m.width,h=m.height;const b=bytes(m.data);if(b.length<m.step*h)throw Error('图像数据不完整');c.width=w;c.height=h;const g=c.getContext('2d'),im=g.createImageData(w,h),out=im.data;let valid=0,center=[];let dv=new DataView(b.buffer,b.byteOffset,b.byteLength);let depth;
 if(key==='depth'){if(!['16UC1','mono16','32FC1'].includes(m.encoding))throw Error('不支持的深度编码 '+m.encoding);depth=new Float32Array(w*h);}
 else if(!['rgb8','bgr8','rgba8','bgra8','mono8'].includes(m.encoding))throw Error('不支持的彩色编码 '+m.encoding);
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){let i=y*w+x,o=i*4;out[o+3]=255;
 if(depth){const p=y*m.step+x*(m.encoding!=='32FC1'?2:4);const v=m.encoding!=='32FC1'?dv.getUint16(p,!m.is_bigendian)/1000:dv.getFloat32(p,!m.is_bigendian);depth[i]=v;if(!Number.isFinite(v)||v<=0)continue;valid++;if(Math.abs(x-w/2)<10&&Math.abs(y-h/2)<10)center.push(v);const t=Math.min(1,v/5);out[o]=255*(1-t);out[o+1]=70+165*Math.sin(Math.PI*t);out[o+2]=255*t;}
 else{const mono=m.encoding==='mono8',stride=mono?1:m.encoding.includes('a8')?4:3,p=y*m.step+x*stride,bgr=m.encoding.startsWith('bgr');out[o]=b[p+(bgr?2:0)];out[o+1]=b[p+(mono?0:1)];out[o+2]=b[p+(mono?0:bgr?0:2)];}}
 g.putImageData(im,0,0);$(key+'Meta').textContent=`${w} × ${h} · ${m.encoding} · ${m.header.frame_id}`;
 if(depth){$('depthPick').textContent='点击深度图选定一个区域，距离将逐帧更新。';lastDepth={values:depth,w,h};center.sort((a,b)=>a-b);$('depthMeta').textContent+=` · 有效 ${(valid/(w*h)*100).toFixed(0)}% · 中央区域 ${center.length?center[Math.floor(center.length/2)].toFixed(2)+' 米':'无数据'}`;updateDepthTarget();}
}
$('radius').onchange=()=>lastScan&&drawScan(lastScan);
$('depth').onclick=e=>{if(!lastDepth||$('depthPanel').classList.contains('stale'))return;const b=e.target.getBoundingClientRect(),d=lastDepth;const scale=Math.min(b.width/d.w,b.height/d.h),ox=(b.width-d.w*scale)/2,oy=(b.height-d.h*scale)/2,x=Math.floor((e.clientX-b.left-ox)/scale),y=Math.floor((e.clientY-b.top-oy)/scale);if(x<0||y<0||x>=d.w||y>=d.h)return;depthTarget={x,y};updateDepthTarget();};
async function poll(){try{const r=await fetch('/state?since='+sequence);if(!r.ok)throw Error('连接失败');const s=await r.json();sequence=s.seq;connected=s.connected;serverNow=s.now;receivedAt=Date.now();latest=s.topics;$('connection').textContent=connected?'已连接 · 只读':'连接中断 · 正在重连';for(const [topic,key]of Object.entries(names)){const t=s.topics[topic];if(t?.msg)try{key==='scan'?drawScan(t.msg):drawImage(t.msg,key);}catch(e){$(key+'Meta').textContent=e.message;}}}catch{$('connection').textContent='本机接收服务未连接';connected=false;}finally{setTimeout(poll,450);}}
setInterval(()=>{for(const[topic,key]of Object.entries(names)){const t=latest[topic],age=t?(serverNow+Date.now()-receivedAt-t.received)/1000:Infinity,stale=!connected||age>3;$(key+'Panel').classList.toggle('stale',stale);$(key+'Fresh').textContent=t?`${stale?'数据过期':'更新中'} · ${age.toFixed(1)} 秒前`:'等待数据';if(key==='scan')refreshDistances(stale);if(key==='depth'&&stale)$('depthPick').textContent='深度数据过期，暂不用于测距。';}},250);poll();
