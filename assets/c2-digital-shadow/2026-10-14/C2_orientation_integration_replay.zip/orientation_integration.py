"""Read-only RGB direction conversion. No translation, TF publishing or actuation."""
from pathlib import Path
import numpy as np
from local_orientation_model import orientation, UnsupportedPose

CONFIG = Path(__file__).with_name('local_orientation_calibration.json')

def convert_directions(vectors_rgb, context=None):
    """Context must come from synchronized capture and verified approach history.

    Joint values alone cannot establish approach history. The live caller does
    not currently supply that evidence and must therefore remain unavailable.
    Output has nominal base axes but absolute yaw is NOT calibrated.
    """
    unavailable = {'status': 'not_applied', 'translation_calibrated': False,
                   'absolute_yaw_calibrated': False}
    try:
        if not context or context.get('approach_verified') is not True:
            return {**unavailable, 'reason': '动作历史未确认，未应用新方向补偿'}
        delta = float(context['joint_image_delta_ms'])
        if not np.isfinite(delta) or abs(delta) > 20:
            return {**unavailable, 'reason': '图像与关节时间差超过20毫秒'}
        v = np.asarray(vectors_rgb, dtype=float)
        if v.ndim != 2 or v.shape[1] != 3 or not np.isfinite(v).all():
            raise ValueError('Expected finite Nx3 optical vectors')
        lengths = np.linalg.norm(v, axis=1)
        if np.any(lengths < 1e-12):
            raise ValueError('Zero direction')
        R = orientation(context['joint_rad'], approach_verified=True, config_path=CONFIG)
        return {'status': 'local_orientation_only',
                'unit_directions_base_axes': ((v / lengths[:, None]) @ R.T).tolist(),
                'rotation_base_from_rgb_optical': R.tolist(),
                'joint_image_delta_ms': delta, 'translation_calibrated': False,
                'absolute_yaw_calibrated': False,
                'meaning': '方向补偿；不是物体绝对坐标，不用于运动控制'}
    except (KeyError, TypeError, ValueError) as exc:
        return {**unavailable, 'reason': str(exc)}
