"""Offline only: detect saved board images and exercise the production adapter."""
from pathlib import Path
import sys,json,base64,hashlib
import numpy as np,cv2
root=Path.cwd();sys.path.insert(0,str(root/'outputs/c2-sensors'))
from orientation_integration import convert_directions,CONFIG
from object_geometry import estimate
data=root/'outputs/c2-charuco-2026-10-14/floor-fixed-segment'
out=root/'outputs/c2-orientation-integration';out.mkdir(exist_ok=True)
board=cv2.aruco.CharucoBoard((5,7),.035,.025,cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_5X5_100));board.setLegacyPattern(False)
checks=[];sources=[];contexts=[];geometry_checks=0
for name,relative in [('joint1_minus5','fast-session-5deg/joint1_minus5.json'),('combo12_minus5','fast-session-5deg/combo12_minus5.json'),('joint0_plus6_joint3_minus6','combo03-stage2-joint3/joint3_minus6.json')]:
 path=data/relative;raw=path.read_bytes();record=json.loads(raw)
 sources.append({'file':str(path.relative_to(root)),'sha256':hashlib.sha256(raw).hexdigest()})
 for i,s in enumerate(record['samples']):
  b=s['bundle'];m=b['color'];im=np.ndarray((m['height'],m['width'],3),np.uint8,buffer=base64.b64decode(m['data']),strides=(m['step'],3,1)).copy()
  cc,ci,_,_=cv2.aruco.CharucoDetector(board).detectBoard(cv2.cvtColor(im,cv2.COLOR_RGB2GRAY));assert ci is not None and len(ci)>=12
  obj=board.getChessboardCorners()[ci.flatten()];K=np.array(b['infos']['color']['k']).reshape(3,3);D=np.array(b['infos']['color']['d'])
  ok,rv,tv=cv2.solvePnP(obj,cc.reshape(-1,2),K,D);assert ok
  n=cv2.Rodrigues(rv)[0][:,2]
  ctx={'joint_rad':s['joint']['q'],'joint_image_delta_ms':(s['joint']['stamp_ns']-b['stamp_ns'])/1e6,'approach_verified':True}
  # Verified outbound experiment captures only, never inferred from q values.
  result=convert_directions([n],ctx);assert result['status']=='local_orientation_only',result
  R=np.array(result['rotation_base_from_rgb_optical']);assert np.allclose(R.T@R,np.eye(3),atol=1e-8) and np.linalg.det(R)>0
  tilt=float(np.degrees(np.arccos(np.clip(abs(result['unit_directions_base_axes'][0][2]),0,1))))
  assert tilt<1.0,(name,tilt)
  checks.append({'pose':name,'frame':i,'corrected_floor_tilt_deg':tilt,'corners':len(ci),'joint_image_delta_ms':ctx['joint_image_delta_ms']})
  contexts.append(ctx)
  # Same estimate() path used by detector; board polygon is a saved-image mask.
  if 'depth' in b:
   mask=np.zeros(im.shape[:2],np.uint8);cv2.fillConvexPoly(mask,cv2.convexHull(cc.astype(np.int32)),1)
   geo=estimate(mask,b['depth'],b['infos']['color'],b['base_from_rgb'],orientation_context=ctx)
   assert geo.get('local_orientation',{}).get('status')=='local_orientation_only',geo
   old=estimate(mask,b['depth'],b['infos']['color'],b['base_from_rgb'])
   assert old['local_orientation']['status']=='not_applied'
   assert geo['base_xyz_m']==old['base_xyz_m'] and geo['candidate_base_xyz_m']==old['candidate_base_xyz_m']
   geometry_checks+=1
ctx=contexts[0];failures=[]
for label,c in [('unknown_history',None),('reverse_history',{**ctx,'approach_verified':False}),('unsynchronized',{**ctx,'joint_image_delta_ms':100}),('nan_time',{**ctx,'joint_image_delta_ms':float('nan')}),('unvalidated_pose',{**ctx,'joint_rad':[1]*6})]:
 r=convert_directions([[0,0,1]],c);assert r['status']=='not_applied' and 'unit_directions_base_axes' not in r;failures.append(label)
assert convert_directions([[0,0,0]],ctx)['status']=='not_applied'
assert CONFIG.read_bytes()==(root/'outputs/c2-ground-orientation-local-v2/calibration.json').read_bytes()
report={'mode':'offline_saved_capture_replay','robot_connected':False,'motion_commands_sent':0,'live_process_restarted':False,'config_unchanged':True,'depth_geometry_frames':geometry_checks,'config_sha256':hashlib.sha256(CONFIG.read_bytes()).hexdigest(),'sources':sources,'frame_checks':checks,'rejection_checks':failures+['zero_direction'],'scope':'Direction only; translation and absolute yaw uncalibrated. Historical outbound context used only for recorded validation captures.'}
(out/'replay_report.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps({'frames':len(checks),'max_tilt_deg':max(x['corrected_floor_tilt_deg'] for x in checks),'rejections':len(failures)+1,'depth_geometry_frames':geometry_checks},indent=2))
